package com.example.githubuser.DetailProfile

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.githubuser.Database.FavDatabase
import com.example.githubuser.Database.FavoriteUser
import com.example.githubuser.Favorite.FavoriteActivity
import com.example.githubuser.Follow.SectionPagerAdapter
import com.example.githubuser.R
import com.example.githubuser.databinding.ActivityProfileUserBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class ProfileUser : AppCompatActivity() {
    private lateinit var binding: ActivityProfileUserBinding
    private lateinit var viewModel: ProfileViewModel
    lateinit var addFAV: FloatingActionButton
    lateinit var db: FavDatabase

    companion object{
        const val USERNAME = "username"
        @StringRes
        private val TAB = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val username = intent.getStringExtra(USERNAME)
        val bundle = Bundle().apply { putString(USERNAME,username) }
        db = Room.databaseBuilder(applicationContext, FavDatabase::class.java, "fav-db").build()
        addFAV = findViewById(R.id.add_favorite)

        addFAV.setOnClickListener {
            getAllDetail(username)
            GlobalScope.launch {
                diplayData()
                if (username != null){
                    Intent(this@ProfileUser, ProfileUser::class.java).also {
                        it.putExtra("username",username)
                        startActivity(it)
                    }
                }
            }
        }

        setTextDetail()
        setAllDetail(username)

        val sectionPagerAdapter = SectionPagerAdapter(this)
        sectionPagerAdapter.username = username.toString()
        binding.viewPager.adapter = sectionPagerAdapter
        TabLayoutMediator(binding.tabMode,binding.viewPager){tabs, position->
            tabs.text = resources.getString(TAB[position])
        }.attach()

        supportActionBar?.elevation = 0f
        GlobalScope.launch {
            diplayData()
            val favT = username?.let { db.favDao().getreadvaluser(it) }
            var k = 0;
            if (favT != null) {

                for (fav in favT) {
                    k = k + 1
                }
                if (k>0)
                {
                    addFAV.setImageResource(R.drawable.ic_baseline_star_24)
                }else{
                    addFAV.setImageResource(R.drawable.ic_baseline_unfavorite24)
                }
            }
        }
    }

    override fun onBackPressed() {
        startActivity(Intent(this, FavoriteActivity::class.java))
        finish()
    }



    private fun setTextDetail(){
        with(binding){
            name.text = ""
            photoProfile.drawable
            userName.text = ""
            followers.text = ""
            following.text =""
            showLoading(true)
        }
    }

    private fun diplayData() {
        val favT = db.favDao().getAllFav()
        var displayText = ""
        for (fav in favT) {
            displayText += "${fav.username} | ${fav.name} | ${fav.avatar_url}"
        }
        Log.d("data dao", "diplayData: "+displayText)
    }

    private fun setAllDetail(username: String?) {
        viewModel = ViewModelProvider(this).get(ProfileViewModel::class.java)
        viewModel.SetUserDetail(username.toString())
        viewModel.getUserDetail().observe(this, { user ->
            user?.let {
                with(binding) {
                    name.text = it.name ?: ""
                    userName.text = it.login ?: ""
                    followers.text = "${it.followers}\nFollowers"
                    following.text = "${it.following}\nFollowing"
                    showLoading(false)
                    Glide.with(this@ProfileUser)
                        .load(it.avatarUrl)
                        .into(photoProfile)
                }
            }
        })
    }


    private fun initData(username: String?, name: String?, img: String) {
        val favT1 = FavoriteUser(username.toString(),name.toString(), img)
        db.favDao().insert(favT1)
    }

    fun getAllDetail(username: String?) {
        addFAV = findViewById(R.id.add_favorite)
        var img = ""
        var name = ""
        viewModel = ViewModelProvider(this).get(ProfileViewModel::class.java)
        viewModel.SetUserDetail(username.toString())
        viewModel.getUserDetail().observe(this) { user ->
            user?.let {
                with(binding) {

                    img = it.avatarUrl
                    name = it.name
                }
            }
        }
        GlobalScope.launch {

            val favT = username?.let { db.favDao().getreadvaluser(it) }
            var k = 0;
            if (favT != null) {

                for (fav in favT) {
                    k = k + 1
                }
            }
            if(k < 1) {
                initData(username, name, img)
                runOnUiThread {
                    Toast.makeText(this@ProfileUser,"Berhasil Menambahkan ke favorit", Toast.LENGTH_SHORT).show()
                }

            }
            else{

                db.favDao().getDelete(username.toString())
                runOnUiThread {
                    Toast.makeText(this@ProfileUser,"Berhasil menghapus dari favorit", Toast.LENGTH_SHORT).show()

                }

            }
            diplayData()
        }

    }






    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE
        else View.GONE
    }
}