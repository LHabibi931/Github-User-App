package com.example.githubuser.Api

import com.example.githubuser.DetailProfile.ProfileUserResponse
import com.example.githubuser.Main.User
import com.example.githubuser.Main.UserResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiGithub {
@GET("search/users")
@Headers ("Authorization: token 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")
    fun getSearch(
            @Query("q") query: String
        ): Call<UserResponse>

    @GET("users/{username}")
    @Headers ("Authorization: token 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")
    fun getUsers(
        @Path("username") username: String
       ): Call<ProfileUserResponse>

    @GET("users/{username}/followers")
    @Headers ("Authorization: token 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")
    fun getFollowers(
        @Path("username") username: String
    ): Call<List<User>>

    @GET("users/{username}/following")
    @Headers ("Authorization: token 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")
    fun getFollowing(@Path("username") username: String): Call<List<User>>
}