package com.example.githubuser.Main

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubuser.Api.ApiConfig
import retrofit2.Call
import retrofit2.Response

class MainViewModel: ViewModel() {

    companion object{
        const val TAG="MainActivity"
    }

     private val list = MutableLiveData<List<User>>()
     private val _isLoading= MutableLiveData<Boolean>()


    fun SearchUser(query: String){
        _isLoading.value = true
        val client = ApiConfig.getApiGithub().getSearch(query)
        client.enqueue(object : retrofit2.Callback<UserResponse>{
            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                _isLoading.value = false
                if (response.isSuccessful){
                        val items = response.body()!!.items
                        list.postValue(items)

                }
                else{
                    Log.e(TAG,"onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG,"onFailure: ${t.message}")
            }

        })

    }

    fun getSearchUser(): LiveData<List<User>> {
        return list

    }



}

