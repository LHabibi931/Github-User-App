package com.example.githubuser.Favorite

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData

data class FavoriteViewModel(
    val username: String,
    val name: String,
    val avatar_url: String
)



