package com.example.githubuser.DetailProfile

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubuser.Api.ApiConfig
import retrofit2.Call
import retrofit2.Response

class ProfileViewModel: ViewModel() {

    val userDetail = MutableLiveData<ProfileUserResponse>()
    private val loading = MutableLiveData<Boolean>()

    companion object{
        private const val TAG ="ProfileViewModel"
    }

    fun SetUserDetail(username: String){
        loading.value = true
        val client = ApiConfig.getApiGithub().getUsers(username)
        client.enqueue(object : retrofit2.Callback<ProfileUserResponse> {
            override fun onResponse(call: Call<ProfileUserResponse>, response: Response<ProfileUserResponse>) {
                if (response.isSuccessful){
                    loading.value = false
                    val items = response.body()
                    userDetail.postValue(items!!)

                }
                else{
                    Log.e(TAG,"onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<ProfileUserResponse>, t: Throwable) {
                loading.value = false
                Log.e(TAG,"onFailure: ${t.message}")
            }


        })

    }

    fun getUserDetail(): LiveData<ProfileUserResponse> {
        return userDetail

    }



}