package com.example.githubuser.Follow

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubuser.Api.ApiConfig
import com.example.githubuser.DetailProfile.ProfileUserResponse
import com.example.githubuser.Main.User
import com.example.githubuser.Main.UserResponse
import retrofit2.Call
import retrofit2.Response

class FollowViewModel: ViewModel() {
        val followersDetail = MutableLiveData<List<User>>()
        val followingDetail = MutableLiveData<List<User>>()
        private val loading = MutableLiveData<Boolean>()

        companion object{
            private const val TAG ="followers"
            private const val _TAG ="following"
        }

        fun SetFollowersDetail(username: String){
            loading.value = true
            val client = ApiConfig.getApiGithub().getFollowers(username)
            client.enqueue(object : retrofit2.Callback<List<User>> {
                override fun onResponse(call: Call<List<User>>, response: Response<List<User>>) {
                    if (response.isSuccessful){
                        loading.value = false
                        val items = response.body()!!
                        followersDetail.postValue(items)

                    }
                    else{
                        Log.e(TAG,"onFailure: ${response.message()}")
                    }
                }

                override fun onFailure(call: Call<List<User>>, t: Throwable) {
                    loading.value = false
                    Log.e(TAG,"onFailure: ${t.message.toString()}")
                }


            })

        }

        fun getFollowersList(): LiveData<List<User>> {
            return followersDetail

        }

        fun SetFollowingDetail(username: String){
            loading.value = true
            val client = ApiConfig.getApiGithub().getFollowing(username)
            client.enqueue(object : retrofit2.Callback<List<User>> {
                override fun onResponse(call: Call<List<User>>, response: Response<List<User>>) {
                    if (response.isSuccessful){
                        loading.value = false
                        val items = response.body()!!
                        followingDetail.postValue(items)

                    }
                    else{
                        Log.e(_TAG,"onFailure: ${response.message()}")
                    }
                }

                override fun onFailure(call: Call<List<User>>, t: Throwable) {
                    loading.value = false
                    Log.e(_TAG,"onFailure: ${t.message.toString()}")
                }


            })

        }

    fun getFollowingsList(): LiveData<List<User>> {
        return followingDetail

    }
}