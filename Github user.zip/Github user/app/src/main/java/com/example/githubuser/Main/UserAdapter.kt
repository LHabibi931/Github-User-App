import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.githubuser.Main.User
import com.example.githubuser.databinding.UserListBinding

class UserAdapter: RecyclerView.Adapter<UserAdapter.ViewHolder>() {

    private val listUser= ArrayList<User>()
    var onItemClick: OnItemClickListener? = null

    interface OnItemClickListener{
        fun onItemClick(user: User)
    }

    inner class ViewHolder(private val binding: UserListBinding, onItemClick: OnItemClickListener?): RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemClick?.onItemClick(listUser[position])
                }
            }
        }

        fun bind(user: User) {
            binding.nameUser.text = user.login
            Glide.with(itemView.context)
                .load(user.avatarUrl)
                .into(binding.photoProfile)
        }

    }

    fun setAlist(user: ArrayList<User>){
        listUser.clear()
        listUser.addAll(user)
        notifyDataSetChanged()

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = UserListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(view, onItemClick)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = listUser[position]
        holder.bind(user)

    }

    override fun getItemCount(): Int = listUser.size
}
