package com.example.githubuser.Main

import UserAdapter
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.R
import com.example.githubuser.databinding.ActivityMainBinding
import androidx.appcompat.widget.SearchView
import com.example.githubuser.DetailProfile.ProfileUser
import com.example.githubuser.Favorite.FavoriteActivity
import com.example.githubuser.Settingtheme.SettingThemeActivity

class MainActivity : AppCompatActivity() {


    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: UserAdapter
    private lateinit var viewModel: MainViewModel
    private lateinit var searchView: SearchView
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        adapter= UserAdapter()
        adapter.notifyDataSetChanged()

        sharedPreferences = getSharedPreferences("night", 0)
        val booleanValue = sharedPreferences.getBoolean("night_mode", true)
        if (booleanValue) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }


        val itemClickListener = object : UserAdapter.OnItemClickListener{
            override fun onItemClick(user: User) {
                Intent(this@MainActivity, ProfileUser::class.java).also {
                    it.putExtra("username",user.login)
                    it.putExtra("id",user.id)
                    it.putExtra("avatar_url",user.avatarUrl)
                    startActivity(it)
                }
            }
        }

        adapter.onItemClick = itemClickListener


        binding.rvUser.layoutManager = LinearLayoutManager(this)
        binding.rvUser.adapter = adapter

        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MainViewModel::class.java)
        viewModel.getSearchUser().observe(this,{
            if (it != null) {
            adapter.setAlist(it as ArrayList<User>)
            showLoading(false)
        }
        })



    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)

        val searchItem = menu.findItem(R.id.search_user)
        searchView = searchItem.actionView as SearchView
        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager

        fun onKey(view: View, keyCode: Int, event: KeyEvent): Boolean {
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                searchUser()
                return true
            }
            return false
        }

        searchView.setOnKeyListener(::onKey)

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextSubmit(query: String): Boolean {
                searchUser()
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.favorite_user -> {
                Intent(this@MainActivity, FavoriteActivity::class.java).also {
                    startActivity(it)
                }
            }
            R.id.setting -> {
                Intent(this@MainActivity, SettingThemeActivity::class.java).also {
                    startActivity(it)
                }
            }
        }
        return super.onOptionsItemSelected(item)


    }


    private fun searchUser(){
        val searchQuery = searchView.query.toString()
        if (searchQuery.isEmpty()){
            Toast.makeText(this,"Please enter a username to search", Toast.LENGTH_SHORT).show()
        }
        else{
            showLoading(true)
            viewModel.SearchUser(searchQuery)
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE
                                         else View.GONE
    }

}




