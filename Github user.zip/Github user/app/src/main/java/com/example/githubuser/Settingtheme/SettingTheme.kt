package com.example.githubuser.Settingtheme

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import com.example.githubuser.R
import com.example.githubuser.databinding.ActivitySettingThemeBinding

class SettingThemeActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingThemeBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingThemeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("night", 0)
        val editor = sharedPreferences.edit()
        editor.putBoolean("night", true)
        editor.commit()

        val booleanValue = sharedPreferences.getBoolean("night_mode", true)
        if (booleanValue) {
            Log.d("TAG", "onCreate: "+booleanValue.toString())
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            binding.switchCompat.isChecked = true
            binding.imageView.setImageResource(R.drawable.night)
            editor.commit()
        }

        binding.switchCompat.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                binding.switchCompat.isChecked = true
                binding.imageView.setImageResource(R.drawable.night)
                val editor = sharedPreferences.edit()
                editor.putBoolean("night_mode", true)
                editor.commit()
            }
            else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                binding.switchCompat.isChecked = false
                binding.imageView.setImageResource(R.drawable.day)
                val editor = sharedPreferences.edit()
                editor.putBoolean("night_mode", false)
                editor.commit()
            }
        }
    }
}