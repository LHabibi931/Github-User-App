package com.example.githubuser.Follow

import UserAdapter
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.DetailProfile.ProfileUser
import com.example.githubuser.Main.User
import com.example.githubuser.R
import com.example.githubuser.databinding.ActivityProfileUserBinding
import com.example.githubuser.databinding.FragmentFollowerBinding


class FollowerFragment : Fragment() {


    private lateinit var binding: FragmentFollowerBinding
    private lateinit var viewModel: FollowViewModel
    private lateinit var adapter: UserAdapter

    var position : Int = 0
    private lateinit var username: String

    companion object {
        const val ARG_NUMBER = "sector_number"
        const val ARG_USERNAME= "username"

    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentFollowerBinding.inflate(inflater,container,false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        arguments?.let {
            position = it.getInt(ARG_NUMBER)
            username = it.getString(ProfileUser.USERNAME).toString()
            viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(FollowViewModel::class.java)

        }

        adapter= UserAdapter()
        adapter.notifyDataSetChanged()

        val itemClickListener = object : UserAdapter.OnItemClickListener{
            override fun onItemClick(user: User) {
                Intent(activity, ProfileUser::class.java).also {
                    it.putExtra("username",user.login)
                    it.putExtra("id",user.id)
                    it.putExtra("avatar_url",user.avatarUrl)
                    startActivity(it)
                }
            }
        }

        adapter.onItemClick = itemClickListener

        binding.rvFollow.layoutManager = LinearLayoutManager(activity)
        binding.rvFollow.adapter = adapter

        if (position == 1){//tab followers
            showLoading(true)
            getFollowers(username)
        }
        else{// tab following


            getFollowing(username)
        }
    }

    private fun getFollowers(username: String){
        viewModel.SetFollowersDetail(username)
        viewModel.getFollowersList().observe(viewLifecycleOwner,{
            if (it != null){
                adapter.setAlist(it as ArrayList<User>)
                showLoading(false)
            }
        })

    }

    private fun getFollowing(username: String){
        viewModel.SetFollowingDetail(username)
        viewModel.getFollowingsList().observe(viewLifecycleOwner,{
            if (it != null){
                adapter.setAlist(it as ArrayList<User>)
                showLoading(false)
            }
        })


    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE
        else View.GONE
    }


}