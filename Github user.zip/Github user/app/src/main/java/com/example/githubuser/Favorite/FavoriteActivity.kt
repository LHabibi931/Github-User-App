package com.example.githubuser.Favorite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.githubuser.Database.FavDatabase
import com.example.githubuser.Main.MainActivity
import com.example.githubuser.databinding.ActivityFavoriteBinding
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class FavoriteActivity : AppCompatActivity() {

    private lateinit var db: FavDatabase
    private lateinit var binding: ActivityFavoriteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val recyclerview = binding.rvFavorite
        recyclerview.layoutManager = LinearLayoutManager(this)
        db = Room.databaseBuilder(applicationContext, FavDatabase::class.java, "fav-db").build()
        val data = ArrayList<FavoriteViewModel>()

        GlobalScope.launch {
            val favT = db.favDao().getAllFav()
            for (fav in favT) {
                data.add(FavoriteViewModel(fav.username,fav.name,fav.avatar_url))
            }
            val adapter = FavoriteAdapter(data)
            recyclerview.adapter = adapter
        }
    }

}