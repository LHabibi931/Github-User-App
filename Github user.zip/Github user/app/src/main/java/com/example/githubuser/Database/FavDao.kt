package com.example.githubuser.Database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface FavDao {
    @Query("SELECT * FROM favorite")
    fun getAllFav():List<FavoriteUser>

    @Insert
    fun insert(vararg favT: FavoriteUser)

    @Delete
    fun delete(favT: FavoriteUser)

    @Query("DELETE FROM favorite")
    fun deleteAll()

    @Query("SELECT * FROM favorite WHERE username LIKE :name")
    fun getreadvaluser(name: String): List<FavoriteUser>


    @Query("DELETE FROM favorite WHERE username LIKE :name")
    fun getDelete(name: String)

}