package com.example.githubuser.Database


import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [FavoriteUser::class], version = 2, exportSchema = true)
abstract class FavDatabase: RoomDatabase() {
    abstract fun favDao(): FavDao

}